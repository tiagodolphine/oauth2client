package com.dolphine.oauth2.client.service;

public class Constants {

	public final static String OAUTH2_CONTEXT_PARAMETER="oauth2context";
	public final static String AUTHORIZATION_SERVER_PARAMETER="authorizationServer";
	
}
